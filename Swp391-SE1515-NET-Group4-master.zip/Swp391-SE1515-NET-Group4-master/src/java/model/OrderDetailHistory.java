/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author Hfyl
 */
public class OrderDetailHistory {

    private String productID;
    private String productName;
    private String imagePath;
    private int quantity;
    private double unitPrice;
    

    public OrderDetailHistory() {
    }

    public OrderDetailHistory(String productID, String productName, String imagePath, int quantity, double unitPrice) {
        this.productID = productID;
        this.productName = productName;
        this.imagePath = imagePath;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    
    
}
