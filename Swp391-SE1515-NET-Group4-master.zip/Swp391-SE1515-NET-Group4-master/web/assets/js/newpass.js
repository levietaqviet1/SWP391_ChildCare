$(window).load(function ()
{
    $('#Modal-NewPass').modal('show');
});



