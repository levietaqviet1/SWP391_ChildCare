$(window).load(function ()
{
    $('#Modal-Registration').modal('show');
});
